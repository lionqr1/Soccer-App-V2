"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { PlayerComparison } from "./player-comparison"
import { ArrowLeft, User, LogOut, Shield, Info, Bell, Upload, Calendar, AlertTriangle, Users } from "lucide-react"

interface SettingsProps {
  currentUser: any
  players: any[]
  matches?: any[]
  onBack: () => void
  onLogout: () => void
  onUpdateProfile: (playerId: string, updates: any) => void
  onSelectMatch?: (match: any) => void
}

export function Settings({
  currentUser,
  players,
  matches = [],
  onBack,
  onLogout,
  onUpdateProfile,
  onSelectMatch,
}: SettingsProps) {
  const [showEditProfile, setShowEditProfile] = useState(false)
  const [showAllMatches, setShowAllMatches] = useState(false)
  const [showComparison, setShowComparison] = useState(false)
  const [uploadMethod, setUploadMethod] = useState<"url" | "file">("url")
  const [editData, setEditData] = useState({
    name: currentUser.name,
    surname: currentUser.surname,
    username: currentUser.username,
    profile_image: currentUser.profile_image || "",
  })

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        // 5MB limit
        alert("File size must be less than 5MB")
        return
      }

      if (!file.type.startsWith("image/")) {
        alert("Please select an image file")
        return
      }

      const reader = new FileReader()
      reader.onload = (event) => {
        const result = event.target?.result as string
        setEditData({ ...editData, profile_image: result })
      }
      reader.onerror = () => {
        alert("Error reading file. Please try again.")
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSaveProfile = async () => {
    try {
      await onUpdateProfile(currentUser.id, editData)
      setShowEditProfile(false)
      alert("Profile updated successfully!")
    } catch (error) {
      console.error("Error updating profile:", error)
      alert("Error updating profile. Please try again.")
    }
  }

  // Calculate player stats
  const playerMatches = matches.filter((match) => match.attendees?.some((attendee) => attendee.id === currentUser.id))

  const playedMatches = playerMatches.filter((match) => {
    const attendee = match.attendees?.find((a) => a.id === currentUser.id)
    return attendee && !attendee.injured && match.status === "completed"
  })

  const totalGoals = matches.reduce((total, match) => {
    const scorer = match.goalScorers?.find((s) => s.playerId === currentUser.id)
    return total + (scorer?.goals || 0)
  }, 0)

  const totalAssists = matches.reduce((total, match) => {
    const assist = match.assists?.find((a) => a.playerId === currentUser.id)
    return total + (assist?.assists || 0)
  }, 0)

  const mvpCount = matches.filter((match) => match.mvp?.id === currentUser.id).length

  if (showComparison) {
    return (
      <PlayerComparison
        currentUser={currentUser}
        players={players}
        matches={matches}
        onBack={() => setShowComparison(false)}
      />
    )
  }

  if (showAllMatches) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white shadow-sm border-b sticky top-0 z-50">
          <div className="px-4 py-3">
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="icon" onClick={() => setShowAllMatches(false)}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <h1 className="text-lg font-semibold text-gray-900">All Matches</h1>
            </div>
          </div>
        </header>

        <main className="p-4">
          {/* Stats Summary */}
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="grid grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-green-600">{totalGoals}</div>
                  <div className="text-xs text-gray-600">Goals</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-blue-600">{totalAssists}</div>
                  <div className="text-xs text-gray-600">Assists</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-yellow-600">{mvpCount}</div>
                  <div className="text-xs text-gray-600">MVP</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-600">{playedMatches.length}</div>
                  <div className="text-xs text-gray-600">Played</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* All Matches */}
          <div className="space-y-3">
            {matches.length > 0 ? (
              matches.map((match) => {
                const scorer = match.goalScorers?.find((s) => s.playerId === currentUser.id)
                const assist = match.assists?.find((a) => a.playerId === currentUser.id)
                const isMVP = match.mvp?.id === currentUser.id
                const attendee = match.attendees?.find((a) => a.id === currentUser.id)
                const wasAttending = !!attendee
                const wasInjured = attendee?.injured

                return (
                  <Card
                    key={match.id}
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => onSelectMatch?.(match)}
                  >
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h4 className="font-semibold text-gray-900">{match.day} Match</h4>
                          <p className="text-sm text-gray-600">{match.location}</p>
                          <p className="text-xs text-gray-500">{new Date(match.date).toLocaleDateString()}</p>
                        </div>
                        <div className="text-right">
                          {match.status === "completed" ? (
                            <div className="text-lg font-bold text-gray-900">{match.score || "0-0"}</div>
                          ) : (
                            <Badge variant="outline">Upcoming</Badge>
                          )}
                        </div>
                      </div>

                      {/* Attendance Status */}
                      <div className="mb-2">
                        {wasAttending ? (
                          <Badge variant={wasInjured ? "destructive" : "default"} className="text-xs">
                            {wasInjured ? "Watched (Injured)" : "Played"}
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="text-xs">
                            Did not attend
                          </Badge>
                        )}
                      </div>

                      {/* Performance Badges */}
                      {(scorer || assist || isMVP) && (
                        <div className="flex space-x-2">
                          {scorer && scorer.goals > 0 && (
                            <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
                              ⚽ {scorer.goals} goal{scorer.goals !== 1 ? "s" : ""}
                            </Badge>
                          )}
                          {assist && assist.assists > 0 && (
                            <Badge variant="secondary" className="bg-blue-100 text-blue-800 text-xs">
                              🅰️ {assist.assists} assist{assist.assists !== 1 ? "s" : ""}
                            </Badge>
                          )}
                          {isMVP && (
                            <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 text-xs">
                              ⭐ MVP
                            </Badge>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )
              })
            ) : (
              <Card>
                <CardContent className="text-center py-8 text-gray-500">
                  <Calendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No matches found</p>
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>
    )
  }

  if (showEditProfile) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white shadow-sm border-b sticky top-0 z-50">
          <div className="px-4 py-3">
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="icon" onClick={() => setShowEditProfile(false)}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <h1 className="text-lg font-semibold text-gray-900">Edit Profile</h1>
            </div>
          </div>
        </header>

        <main className="p-4">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <Avatar className="w-24 h-24 ring-4 ring-white shadow-lg">
                    <AvatarImage
                      src={editData.profile_image || "/placeholder.svg"}
                      onError={(e) => {
                        console.log("Profile image failed to load:", editData.profile_image)
                        e.currentTarget.src = "/placeholder.svg"
                      }}
                    />
                    <AvatarFallback className="text-2xl font-bold bg-white">
                      {editData.name?.[0] || "?"}
                      {editData.surname?.[0] || "?"}
                    </AvatarFallback>
                  </Avatar>
                  {currentUser.injured && (
                    <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center ring-2 ring-white">
                      <AlertTriangle className="w-3 h-3 text-white" />
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">First Name</Label>
                  <Input
                    id="name"
                    value={editData.name}
                    onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="surname">Last Name</Label>
                  <Input
                    id="surname"
                    value={editData.surname}
                    onChange={(e) => setEditData({ ...editData, surname: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  value={editData.username}
                  onChange={(e) => setEditData({ ...editData, username: e.target.value })}
                />
              </div>

              {/* Profile Picture Upload */}
              <div>
                <Label>Profile Picture</Label>
                <Tabs value={uploadMethod} onValueChange={(value) => setUploadMethod(value as "url" | "file")}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="url">URL</TabsTrigger>
                    <TabsTrigger value="file">Upload File</TabsTrigger>
                  </TabsList>
                  <TabsContent value="url">
                    <Input
                      value={editData.profile_image}
                      onChange={(e) => setEditData({ ...editData, profile_image: e.target.value })}
                      placeholder="https://example.com/profile.jpg"
                    />
                  </TabsContent>
                  <TabsContent value="file">
                    <div className="flex items-center space-x-2">
                      <Input type="file" accept="image/*" onChange={handleFileUpload} />
                      <Upload className="w-4 h-4 text-gray-500" />
                    </div>
                  </TabsContent>
                </Tabs>

                {/* Profile Picture Preview */}
                {editData.profile_image && (
                  <div className="mt-3">
                    <Label className="text-sm text-gray-600">Preview:</Label>
                    <div className="flex items-center space-x-3 mt-2">
                      <Avatar className="w-12 h-12 ring-2 ring-white">
                        <AvatarImage
                          src={editData.profile_image || "/placeholder.svg"}
                          alt="Profile preview"
                          onError={(e) => {
                            console.log("Preview image failed to load:", editData.profile_image)
                            e.currentTarget.src = "/placeholder.svg"
                          }}
                        />
                        <AvatarFallback className="bg-white">
                          {editData.name?.[0] || "?"}
                          {editData.surname?.[0] || "?"}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-sm text-gray-600">Profile picture preview</span>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex space-x-2 pt-4">
                <Button onClick={handleSaveProfile} className="flex-1">
                  Save Changes
                </Button>
                <Button variant="outline" onClick={() => setShowEditProfile(false)} className="flex-1">
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <h1 className="text-lg font-semibold text-gray-900">Settings</h1>
            </div>
            {/* Profile Picture with Comparison Button */}
            <Button variant="ghost" size="icon" onClick={() => setShowComparison(true)} className="relative">
              <Avatar className="w-8 h-8 ring-2 ring-white">
                <AvatarImage
                  src={currentUser.profile_image || "/placeholder.svg"}
                  onError={(e) => {
                    e.currentTarget.src = "/placeholder.svg"
                  }}
                />
                <AvatarFallback className="text-sm font-bold bg-white">
                  {currentUser.name?.[0] || "?"}
                  {currentUser.surname?.[0] || "?"}
                </AvatarFallback>
              </Avatar>
              {currentUser.injured && (
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center ring-1 ring-white">
                  <AlertTriangle className="w-2 h-2 text-white" />
                </div>
              )}
            </Button>
          </div>
        </div>
      </header>

      <main className="p-4 pb-20">
        {/* Profile Section */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Avatar className="w-16 h-16 ring-4 ring-white shadow-lg">
                  <AvatarImage
                    src={currentUser.profile_image || "/placeholder.svg"}
                    onError={(e) => {
                      e.currentTarget.src = "/placeholder.svg"
                    }}
                  />
                  <AvatarFallback className="text-xl font-bold bg-white">
                    {currentUser.name?.[0] || "?"}
                    {currentUser.surname?.[0] || "?"}
                  </AvatarFallback>
                </Avatar>
                {currentUser.injured && (
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center ring-2 ring-white">
                    <AlertTriangle className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold text-gray-900">
                  {currentUser.name} {currentUser.surname}
                </h2>
                <p className="text-gray-600">@{currentUser.username}</p>
                <div className="flex space-x-2 mt-1">
                  <p className="text-sm text-gray-500 capitalize">{currentUser.role}</p>
                  {currentUser.injured && (
                    <Badge variant="destructive" className="text-xs">
                      Injured
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Settings Options */}
        <div className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Button
                variant="ghost"
                className="w-full justify-start p-4 h-auto"
                onClick={() => setShowEditProfile(true)}
              >
                <User className="w-5 h-5 mr-3 text-gray-500" />
                <div className="text-left">
                  <div className="font-medium">Edit Profile</div>
                  <div className="text-sm text-gray-500">Update your personal information</div>
                </div>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-0">
              <Button
                variant="ghost"
                className="w-full justify-start p-4 h-auto"
                onClick={() => setShowComparison(true)}
              >
                <Users className="w-5 h-5 mr-3 text-gray-500" />
                <div className="text-left">
                  <div className="font-medium">Compare Performance</div>
                  <div className="text-sm text-gray-500">Compare your stats with other players</div>
                </div>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-0">
              <Button
                variant="ghost"
                className="w-full justify-start p-4 h-auto"
                onClick={() => setShowAllMatches(true)}
              >
                <Calendar className="w-5 h-5 mr-3 text-gray-500" />
                <div className="text-left">
                  <div className="font-medium">View All Matches</div>
                  <div className="text-sm text-gray-500">See your complete match history and stats</div>
                </div>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-0">
              <Button variant="ghost" className="w-full justify-start p-4 h-auto">
                <Bell className="w-5 h-5 mr-3 text-gray-500" />
                <div className="text-left">
                  <div className="font-medium">Notifications</div>
                  <div className="text-sm text-gray-500">Manage your notification preferences</div>
                </div>
              </Button>
            </CardContent>
          </Card>

          {currentUser.role === "admin" && (
            <Card>
              <CardContent className="p-0">
                <Button variant="ghost" className="w-full justify-start p-4 h-auto">
                  <Shield className="w-5 h-5 mr-3 text-gray-500" />
                  <div className="text-left">
                    <div className="font-medium">Admin Settings</div>
                    <div className="text-sm text-gray-500">Manage team settings</div>
                  </div>
                </Button>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardContent className="p-0">
              <Button variant="ghost" className="w-full justify-start p-4 h-auto">
                <Info className="w-5 h-5 mr-3 text-gray-500" />
                <div className="text-left">
                  <div className="font-medium">About</div>
                  <div className="text-sm text-gray-500">App version and information</div>
                </div>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Logout Button */}
        <Card className="mt-8">
          <CardContent className="p-0">
            <Button
              variant="ghost"
              className="w-full justify-start p-4 h-auto text-red-600 hover:text-red-700 hover:bg-red-50"
              onClick={onLogout}
            >
              <LogOut className="w-5 h-5 mr-3" />
              <div className="text-left">
                <div className="font-medium">Sign Out</div>
                <div className="text-sm text-red-500">Sign out of your account</div>
              </div>
            </Button>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
