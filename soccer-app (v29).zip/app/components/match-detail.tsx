"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LiveStream } from "./live-stream"
import {
  ArrowLeft,
  MapPin,
  Calendar,
  Clock,
  Users,
  Trophy,
  Check,
  X,
  Target,
  AlertTriangle,
  Edit2,
  Trash2,
  ExternalLink,
  Wifi,
} from "lucide-react"

interface MatchDetailProps {
  match: any
  currentUser: any
  players: any[]
  onBack: () => void
  onRSVP: (matchId: string, attending: boolean) => void
  onUpdateMatch: (matchId: string, updates: any) => void
  onDeleteMatch?: (matchId: string) => void
  onSelectPlayer?: (player: any) => void
  isAdmin?: boolean
}

export function MatchDetail({
  match,
  currentUser,
  players,
  onBack,
  onRSVP,
  onUpdateMatch,
  onDeleteMatch,
  onSelectPlayer,
  isAdmin = false,
}: MatchDetailProps) {
  const [showAdminControls, setShowAdminControls] = useState(false)
  const [showEditRSVP, setShowEditRSVP] = useState(false)
  const [showLiveStream, setShowLiveStream] = useState(false)
  const [score, setScore] = useState(match.score || "")
  const [mvpId, setMvpId] = useState(match.mvp?.id?.toString() || "none")
  const [videoHighlight, setVideoHighlight] = useState(match.video_highlight || "")
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [locationImage, setLocationImage] = useState(match.location_image || "")
  const [goalScorers, setGoalScorers] = useState(match.goalScorers || [])
  const [assists, setAssists] = useState(match.assists || [])
  const [uploadMethod, setUploadMethod] = useState<"url" | "file">("url")

  const isAttending = match.attendees.some((a) => a.id === currentUser.id)
  const attendeeCount = match.attendees.length

  // Filter out injured players who are attending from the separate injured players section
  const attendingPlayerIds = match.attendees.map((a) => a.id)
  const nonAttendingInjuredPlayers =
    match.injuredPlayers?.filter((player) => !attendingPlayerIds.includes(player.id)) || []

  const handleGoalScorer = (playerId, goals) => {
    setGoalScorers((prev) => {
      const existing = prev.find((s) => s.playerId === playerId)
      if (existing) {
        return prev.map((s) => (s.playerId === playerId ? { ...s, goals: Number.parseInt(goals) || 0 } : s))
      } else {
        return [...prev, { playerId, goals: Number.parseInt(goals) || 0 }]
      }
    })
  }

  const handleAssist = (playerId, assistCount) => {
    setAssists((prev) => {
      const existing = prev.find((a) => a.playerId === playerId)
      if (existing) {
        return prev.map((a) => (a.playerId === playerId ? { ...a, assists: Number.parseInt(assistCount) || 0 } : a))
      } else {
        return [...prev, { playerId, assists: Number.parseInt(assistCount) || 0 }]
      }
    })
  }

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (file.size > 100 * 1024 * 1024) {
        // 100MB limit
        alert("Video file size must be less than 100MB")
        return
      }

      if (!file.type.startsWith("video/")) {
        alert("Please select a video file")
        return
      }

      setVideoFile(file)

      // Create a blob URL for preview
      const blobUrl = URL.createObjectURL(file)
      setVideoHighlight(blobUrl)
    }
  }

  const handleUpdateMatch = async () => {
    const updates = {
      score: score || null,
      mvp: mvpId !== "none" ? players.find((p) => p.id === Number.parseInt(mvpId)) : null,
      video_highlight: videoHighlight || null,
      location_image: locationImage || null,
      full_time: !!score,
      status: score ? "completed" : "upcoming",
      goalScorers: goalScorers.filter((s) => s.goals > 0),
      assists: assists.filter((a) => a.assists > 0),
    }

    try {
      await onUpdateMatch(match.id, updates)
      setShowAdminControls(false)
      alert("Match updated successfully!")
    } catch (error) {
      console.error("Error updating match:", error)
      alert("Error updating match. Please try again.")
    }
  }

  const handleDeleteMatch = async () => {
    if (confirm("Are you sure you want to delete this match? This action cannot be undone.")) {
      try {
        await onDeleteMatch?.(match.id)
        onBack()
      } catch (error) {
        console.error("Error deleting match:", error)
      }
    }
  }

  const handleRSVPChange = (attending: boolean) => {
    onRSVP(match.id, attending)
    setShowEditRSVP(false)
  }

  const handleLocationClick = () => {
    if (match.location_address) {
      // Check if it's already a URL
      if (match.location_address.startsWith("http")) {
        window.open(match.location_address, "_blank")
      } else {
        // Assume it's an address and create Google Maps URL
        const mapsUrl = `https://maps.google.com/?q=${encodeURIComponent(match.location_address)}`
        window.open(mapsUrl, "_blank")
      }
    }
  }

  const handleLiveStreamEnd = (finalScore: string) => {
    onUpdateMatch(match.id, {
      score: finalScore,
      status: "completed",
      full_time: true,
      is_live: false,
    })
    setShowLiveStream(false)
  }

  const formatTime = (time: string) => {
    if (!time) return ""
    const [hours, minutes] = time.split(":")
    const hour = Number.parseInt(hours)
    const ampm = hour >= 12 ? "PM" : "AM"
    const displayHour = hour % 12 || 12
    return `${displayHour}:${minutes} ${ampm}`
  }

  // Show live stream
  if (showLiveStream) {
    return (
      <LiveStream
        match={match}
        currentUser={currentUser}
        players={players}
        onBack={() => setShowLiveStream(false)}
        onUpdateScore={(homeScore, awayScore) => {
          // Only update live score, don't end match
          const liveScore = `${homeScore}-${awayScore}`
          onUpdateMatch(match.id, { score: liveScore, is_live: true })
        }}
        onEndMatch={handleLiveStreamEnd}
        isAdmin={isAdmin}
      />
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <h1 className="text-lg font-semibold text-gray-900">Match Details</h1>
            </div>
            <div className="flex items-center space-x-2">
              {isAdmin && match.status === "upcoming" && (
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => setShowLiveStream(true)}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  <Wifi className="w-4 h-4 mr-2" />
                  Stream Game
                </Button>
              )}
              {isAdmin && onDeleteMatch && (
                <Button variant="ghost" size="icon" onClick={handleDeleteMatch} className="text-red-600">
                  <Trash2 className="w-5 h-5" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="pb-20">
        {/* Match Header */}
        <div className="bg-white">
          <div className="relative">
            <img
              src={match.location_image || "/placeholder.svg?height=200&width=400"}
              alt={match.location}
              className="w-full h-48 object-cover"
              onError={(e) => {
                console.log("Match location image failed to load:", match.location_image)
                e.currentTarget.src = "/placeholder.svg?height=200&width=400"
              }}
            />
            <div className="absolute inset-0 bg-black bg-opacity-20" />
            <div className="absolute bottom-4 left-4 right-4">
              <div className="text-white">
                <h2 className="text-xl font-bold">{match.day} Match</h2>
                <p className="text-sm opacity-90">{match.location}</p>
              </div>
            </div>
          </div>

          <div className="p-4">
            <div className="flex justify-between items-center mb-4">
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Calendar className="w-4 h-4" />
                  <span>{new Date(match.date).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Clock className="w-4 h-4" />
                  <span>{formatTime(match.time)}</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <div className="flex flex-col">
                    <span>{match.location}</span>
                    {match.location_address && (
                      <button
                        onClick={handleLocationClick}
                        className="text-blue-600 hover:text-blue-800 underline text-xs mt-1 flex items-center space-x-1 text-left"
                      >
                        <ExternalLink className="w-3 h-3" />
                        <span>View on map</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {match.status === "completed" && match.score && (
                <div className="text-center">
                  <div className="text-3xl font-bold text-gray-900">{match.score}</div>
                  <Badge variant="secondary" className="mt-1">
                    <Trophy className="w-3 h-3 mr-1" />
                    Full Time
                  </Badge>
                </div>
              )}
            </div>

            {/* Enhanced RSVP Section for Players Only */}
            {match.status === "upcoming" && !isAdmin && (
              <div className="mb-4">
                {!showEditRSVP ? (
                  <div className="space-y-3">
                    {/* Current Status Display */}
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${isAttending ? "bg-green-500" : "bg-red-500"}`} />
                        <span className="font-medium text-gray-900">
                          You are {isAttending ? "going" : "not going"} to this match
                        </span>
                        {isAttending && currentUser.injured && (
                          <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
                            Watching (Injured)
                          </Badge>
                        )}
                      </div>
                      <Button variant="outline" size="sm" onClick={() => setShowEditRSVP(true)}>
                        <Edit2 className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <h3 className="font-semibold text-gray-900">Update your attendance</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <Button
                        variant={isAttending ? "default" : "outline"}
                        onClick={() => handleRSVPChange(true)}
                        className={`h-12 flex flex-col items-center justify-center space-y-1 ${
                          isAttending
                            ? currentUser.injured
                              ? "bg-orange-600 hover:bg-orange-700 text-white"
                              : "bg-green-600 hover:bg-green-700 text-white"
                            : "border-green-600 text-green-600 hover:bg-green-50"
                        }`}
                      >
                        <Check className="w-5 h-5" />
                        <span className="text-sm font-medium">{currentUser.injured ? "Watch" : "Play"}</span>
                      </Button>
                      <Button
                        variant={!isAttending ? "default" : "outline"}
                        onClick={() => handleRSVPChange(false)}
                        className={`h-12 flex flex-col items-center justify-center space-y-1 ${
                          !isAttending
                            ? "bg-red-600 hover:bg-red-700 text-white"
                            : "border-red-600 text-red-600 hover:bg-red-50"
                        }`}
                      >
                        <X className="w-5 h-5" />
                        <span className="text-sm font-medium">Can't Make It</span>
                      </Button>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => setShowEditRSVP(false)} className="w-full">
                      Cancel
                    </Button>
                  </div>
                )}
              </div>
            )}

            {/* Live Stream Button for Players */}
            {!isAdmin && match.status === "upcoming" && (
              <div className="mb-4">
                <Button
                  variant="outline"
                  onClick={() => setShowLiveStream(true)}
                  className="w-full border-red-600 text-red-600 hover:bg-red-50"
                >
                  <Wifi className="w-4 h-4 mr-2" />
                  Watch Live Stream
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Tabs */}
        <div className="p-4">
          <Tabs defaultValue="facts" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="facts">Facts</TabsTrigger>
              <TabsTrigger value="players">Players</TabsTrigger>
            </TabsList>

            {/* Facts Tab */}
            <TabsContent value="facts" className="space-y-4 mt-4">
              {/* Video Highlights */}
              {match.video_highlight && (
                <Card>
                  <CardContent className="p-4">
                    <div className="bg-gray-900 rounded-lg overflow-hidden">
                      <video
                        controls
                        className="w-full h-48 object-cover"
                        poster="/placeholder.svg?height=200&width=400"
                      >
                        <source src={match.video_highlight} type="video/mp4" />
                        <source src={match.video_highlight} type="video/webm" />
                        Your browser does not support the video tag.
                      </video>
                      <div className="p-4">
                        <h3 className="font-semibold mb-2 text-white">Match Highlights</h3>
                        <p className="text-sm text-gray-300">
                          {match.day} Match - {new Date(match.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* MVP Section */}
              {match.mvp && (
                <Card>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-3">Player of the match</h3>
                    <div
                      className="flex items-center space-x-3 cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors"
                      onClick={() => onSelectPlayer?.(match.mvp)}
                    >
                      <Avatar className="w-12 h-12 ring-2 ring-white">
                        <AvatarImage
                          src={match.mvp.profile_image || "/placeholder.svg"}
                          onError={(e) => {
                            e.currentTarget.src = "/placeholder.svg"
                          }}
                        />
                        <AvatarFallback className="text-lg font-semibold bg-white">
                          {match.mvp.name?.[0] || "?"}
                          {match.mvp.surname?.[0] || "?"}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="bg-blue-600 text-white text-xs px-2 py-1 rounded font-bold">8.2</span>
                          <span className="font-semibold text-gray-900">
                            {match.mvp.name} {match.mvp.surname}
                          </span>
                          {match.mvp.injured && <AlertTriangle className="w-4 h-4 text-red-500" />}
                        </div>
                        <p className="text-sm text-gray-600">Outstanding performance</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Goal Scorers */}
              {match.goalScorers && match.goalScorers.length > 0 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center space-x-2 text-lg">
                      <Target className="w-5 h-5 text-green-600" />
                      <span>Goal Scorers</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {match.goalScorers.map((scorer) => {
                        const player = players.find((p) => p.id === scorer.playerId)
                        return player ? (
                          <div
                            key={scorer.playerId}
                            className="flex items-center justify-between cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors"
                            onClick={() => onSelectPlayer?.(player)}
                          >
                            <div className="flex items-center space-x-3">
                              <div className="relative">
                                <Avatar className="w-10 h-10 ring-2 ring-white">
                                  <AvatarImage
                                    src={player.profile_image || "/placeholder.svg"}
                                    alt={`${player.name} ${player.surname}`}
                                    onError={(e) => {
                                      e.currentTarget.src = "/placeholder.svg"
                                    }}
                                  />
                                  <AvatarFallback className="bg-white">
                                    {player.name?.[0] || "?"}
                                    {player.surname?.[0] || "?"}
                                  </AvatarFallback>
                                </Avatar>
                                {player.injured && (
                                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                                    <AlertTriangle className="w-2 h-2 text-white" />
                                  </div>
                                )}
                              </div>
                              <div>
                                <div className="font-medium text-gray-900">
                                  {player.name} {player.surname}
                                </div>
                                <div className="text-sm text-gray-600">Goal scorer</div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-lg font-bold text-green-600">
                                {scorer.goals} goal{scorer.goals !== 1 ? "s" : ""}
                              </div>
                            </div>
                          </div>
                        ) : null
                      })}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Assists */}
              {match.assists && match.assists.length > 0 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center space-x-2 text-lg">
                      <Users className="w-5 h-5 text-blue-600" />
                      <span>Assists</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {match.assists.map((assist) => {
                        const player = players.find((p) => p.id === assist.playerId)
                        return player ? (
                          <div
                            key={assist.playerId}
                            className="flex items-center justify-between cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors"
                            onClick={() => onSelectPlayer?.(player)}
                          >
                            <div className="flex items-center space-x-3">
                              <div className="relative">
                                <Avatar className="w-10 h-10 ring-2 ring-white">
                                  <AvatarImage
                                    src={player.profile_image || "/placeholder.svg"}
                                    alt={`${player.name} ${player.surname}`}
                                    onError={(e) => {
                                      e.currentTarget.src = "/placeholder.svg"
                                    }}
                                  />
                                  <AvatarFallback className="bg-white">
                                    {player.name?.[0] || "?"}
                                    {player.surname?.[0] || "?"}
                                  </AvatarFallback>
                                </Avatar>
                                {player.injured && (
                                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                                    <AlertTriangle className="w-2 h-2 text-white" />
                                  </div>
                                )}
                              </div>
                              <div>
                                <div className="font-medium text-gray-900">
                                  {player.name} {player.surname}
                                </div>
                                <div className="text-sm text-gray-600">Assist provider</div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-lg font-bold text-blue-600">
                                {assist.assists} assist{assist.assists !== 1 ? "s" : ""}
                              </div>
                            </div>
                          </div>
                        ) : null
                      })}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Players Tab */}
            <TabsContent value="players" className="space-y-4 mt-4">
              {/* Attending Players */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center space-x-2 text-lg">
                    <Users className="w-5 h-5 text-green-600" />
                    <span>
                      Attendees ({attendeeCount}) - {match.attendees?.filter((a) => !a.injured).length || 0} Playing,{" "}
                      {match.attendees?.filter((a) => a.injured).length || 0} Watching
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {attendeeCount > 0 ? (
                    <div className="space-y-3">
                      {match.attendees.map((attendee) => (
                        <div
                          key={attendee.id}
                          className="flex items-center justify-between cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors"
                          onClick={() => onSelectPlayer?.(attendee)}
                        >
                          <div className="flex items-center space-x-3">
                            <div className="relative">
                              <Avatar className="w-10 h-10 ring-2 ring-white">
                                <AvatarImage
                                  src={attendee.profile_image || "/placeholder.svg"}
                                  onError={(e) => {
                                    e.currentTarget.src = "/placeholder.svg"
                                  }}
                                />
                                <AvatarFallback className="bg-white">
                                  {attendee.name?.[0] || "?"}
                                  {attendee.surname?.[0] || "?"}
                                </AvatarFallback>
                              </Avatar>
                              {attendee.injured && (
                                <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                                  <AlertTriangle className="w-2 h-2 text-white" />
                                </div>
                              )}
                            </div>
                            <div>
                              <div className="font-medium text-gray-900">
                                {attendee.name} {attendee.surname}
                              </div>
                              <div className={`text-sm ${attendee.injured ? "text-orange-600" : "text-green-600"}`}>
                                {attendee.injured ? "Watching (Injured)" : "Playing"}
                              </div>
                            </div>
                          </div>
                          <Badge variant={attendee.injured ? "destructive" : "default"} className="text-xs">
                            {attendee.injured ? "Injured" : "Active"}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-4 text-gray-500">
                      <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p>No players confirmed yet</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Non-Attending Injured Players */}
              {nonAttendingInjuredPlayers.length > 0 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center space-x-2 text-lg">
                      <AlertTriangle className="w-5 h-5 text-red-600" />
                      <span>Injured Players Not Attending ({nonAttendingInjuredPlayers.length})</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {nonAttendingInjuredPlayers.map((player) => (
                        <div
                          key={player.id}
                          className="flex items-center space-x-3 cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors"
                          onClick={() => onSelectPlayer?.(player)}
                        >
                          <div className="relative">
                            <Avatar className="w-10 h-10 ring-2 ring-white">
                              <AvatarImage
                                src={player.profile_image || "/placeholder.svg"}
                                onError={(e) => {
                                  e.currentTarget.src = "/placeholder.svg"
                                }}
                              />
                              <AvatarFallback className="bg-white">
                                {player.name?.[0] || "?"}
                                {player.surname?.[0] || "?"}
                              </AvatarFallback>
                            </Avatar>
                            <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                              <AlertTriangle className="w-2 h-2 text-white" />
                            </div>
                          </div>
                          <div>
                            <div className="font-medium text-gray-900">
                              {player.name} {player.surname}
                            </div>
                            <div className="text-sm text-red-600">Injured - Not attending</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Show message if all injured players are attending */}
              {match.injuredPlayers?.length > 0 && nonAttendingInjuredPlayers.length === 0 && (
                <Card>
                  <CardContent className="text-center py-6 text-gray-500">
                    <AlertTriangle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">All injured players are attending to watch</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>

        {/* Admin Controls */}
        {isAdmin && (
          <Card className="mx-4 mb-4">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Admin Controls</CardTitle>
            </CardHeader>
            <CardContent>
              {!showAdminControls ? (
                <div className="space-y-2">
                  <Button onClick={() => setShowAdminControls(true)} className="w-full">
                    Update Match
                  </Button>
                  {onDeleteMatch && (
                    <Button variant="destructive" onClick={handleDeleteMatch} className="w-full">
                      Delete Match
                    </Button>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="score">Final Score</Label>
                    <Input
                      id="score"
                      value={score}
                      onChange={(e) => setScore(e.target.value)}
                      placeholder="e.g., 2-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="mvp">Player of the Match</Label>
                    <Select value={mvpId} onValueChange={setMvpId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select MVP" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No MVP</SelectItem>
                        {players
                          .filter((p) => p.role === "player")
                          .map((player) => (
                            <SelectItem key={player.id} value={player.id.toString()}>
                              {player.name} {player.surname}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Video Highlights</Label>
                    <div className="space-y-2">
                      <div className="flex space-x-2">
                        <Button
                          type="button"
                          variant={uploadMethod === "url" ? "default" : "outline"}
                          size="sm"
                          onClick={() => setUploadMethod("url")}
                        >
                          URL
                        </Button>
                        <Button
                          type="button"
                          variant={uploadMethod === "file" ? "default" : "outline"}
                          size="sm"
                          onClick={() => setUploadMethod("file")}
                        >
                          Upload File
                        </Button>
                      </div>

                      {uploadMethod === "url" ? (
                        <Input
                          value={videoHighlight}
                          onChange={(e) => setVideoHighlight(e.target.value)}
                          placeholder="Video URL"
                        />
                      ) : (
                        <div>
                          <input
                            type="file"
                            accept="video/*"
                            onChange={handleVideoUpload}
                            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                          />
                          <p className="text-xs text-gray-500 mt-1">Max file size: 100MB</p>
                          {videoFile && (
                            <p className="text-sm text-green-600 mt-1">
                              Selected: {videoFile.name} ({(videoFile.size / 1024 / 1024).toFixed(2)} MB)
                            </p>
                          )}
                        </div>
                      )}

                      {videoHighlight && (
                        <div className="mt-2">
                          <video controls className="w-full h-32 object-cover rounded">
                            <source src={videoHighlight} type="video/mp4" />
                            <source src={videoHighlight} type="video/webm" />
                            Your browser does not support the video tag.
                          </video>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="location-image">Location Image URL</Label>
                    <Input
                      id="location-image"
                      value={locationImage}
                      onChange={(e) => setLocationImage(e.target.value)}
                      placeholder="Location image URL"
                    />
                  </div>

                  {/* Goal Scorers */}
                  <div>
                    <Label>Goal Scorers</Label>
                    <div className="space-y-2">
                      {players
                        .filter((p) => p.role === "player")
                        .map((player) => {
                          const currentGoals = goalScorers.find((s) => s.playerId === player.id.toString())?.goals || 0
                          return (
                            <div key={player.id} className="flex items-center space-x-2">
                              <span className="text-sm w-32 truncate">
                                {player.name} {player.surname}
                              </span>
                              <Input
                                type="number"
                                min="0"
                                max="10"
                                value={currentGoals}
                                onChange={(e) => handleGoalScorer(player.id.toString(), e.target.value)}
                                className="w-20"
                                placeholder="0"
                              />
                              <span className="text-sm text-gray-500">goals</span>
                            </div>
                          )
                        })}
                    </div>
                  </div>

                  {/* Assists */}
                  <div>
                    <Label>Assists</Label>
                    <div className="space-y-2">
                      {players
                        .filter((p) => p.role === "player")
                        .map((player) => {
                          const currentAssists = assists.find((a) => a.playerId === player.id.toString())?.assists || 0
                          return (
                            <div key={player.id} className="flex items-center space-x-2">
                              <span className="text-sm w-32 truncate">
                                {player.name} {player.surname}
                              </span>
                              <Input
                                type="number"
                                min="0"
                                max="10"
                                value={currentAssists}
                                onChange={(e) => handleAssist(player.id.toString(), e.target.value)}
                                className="w-20"
                                placeholder="0"
                              />
                              <span className="text-sm text-gray-500">assists</span>
                            </div>
                          )
                        })}
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button onClick={handleUpdateMatch} className="flex-1">
                      Save Changes
                    </Button>
                    <Button variant="outline" onClick={() => setShowAdminControls(false)} className="flex-1">
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}
