"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  Camera,
  CameraOff,
  RotateCcw,
  ArrowLeft,
  Plus,
  Minus,
  Play,
  Square,
  Mic,
  MicOff,
  Send,
  Maximize,
  MessageCircle,
  Eye,
  VideoIcon,
  Target,
} from "lucide-react"

interface LiveStreamProps {
  match: any
  currentUser?: any
  players?: any[]
  viewers?: any[]
  onBack: () => void
  onUpdateScore: (homeScore: number, awayScore: number) => void
  onSendMessage?: (message: string) => void
  onUpdateViewers?: (viewers: any[]) => void
  onEndMatch?: (finalScore: string) => void
  isAdmin?: boolean
}

export function LiveStream({
  match,
  currentUser,
  players = [],
  viewers = [],
  onBack,
  onUpdateScore,
  onSendMessage,
  onUpdateViewers,
  onEndMatch,
  isAdmin = false,
}: LiveStreamProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const recordedChunksRef = useRef<Blob[]>([])

  const [isStreaming, setIsStreaming] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [facingMode, setFacingMode] = useState<"user" | "environment">("environment")
  const [homeScore, setHomeScore] = useState(0)
  const [awayScore, setAwayScore] = useState(0)
  const [streamError, setStreamError] = useState("")
  const [isMuted, setIsMuted] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [showChat, setShowChat] = useState(false)
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<any[]>([])
  const [recordingDuration, setRecordingDuration] = useState(0)
  const [recordingInterval, setRecordingInterval] = useState<NodeJS.Timeout | null>(null)

  // Goal/Assist tracking
  const [showGoalDialog, setShowGoalDialog] = useState(false)
  const [goalScorerId, setGoalScorerId] = useState("")
  const [assistPlayerId, setAssistPlayerId] = useState("")
  const [pendingGoalTeam, setPendingGoalTeam] = useState<"home" | "away" | null>(null)

  // Parse existing score if available
  useEffect(() => {
    if (match.score) {
      const [home, away] = match.score.split("-").map((s) => Number.parseInt(s.trim()) || 0)
      setHomeScore(home)
      setAwayScore(away)
    }
  }, [match.score])

  // Add current user to viewers when component mounts
  useEffect(() => {
    if (!isAdmin && currentUser) {
      const updatedViewers = [...viewers]
      if (!updatedViewers.find((v) => v.id === currentUser.id)) {
        updatedViewers.push(currentUser)
        onUpdateViewers?.(updatedViewers)
      }
    }
  }, [currentUser, isAdmin])

  // Recording duration timer
  useEffect(() => {
    if (isRecording) {
      const interval = setInterval(() => {
        setRecordingDuration((prev) => prev + 1)
      }, 1000)
      setRecordingInterval(interval)
    } else {
      if (recordingInterval) {
        clearInterval(recordingInterval)
        setRecordingInterval(null)
      }
      setRecordingDuration(0)
    }

    return () => {
      if (recordingInterval) {
        clearInterval(recordingInterval)
      }
    }
  }, [isRecording])

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const startCamera = async () => {
    try {
      setStreamError("")

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Camera access is not supported in this browser")
      }

      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }

      const constraints = {
        video: {
          facingMode: facingMode,
          width: { ideal: 1920, min: 1280 },
          height: { ideal: 1080, min: 720 },
        },
        audio: !isMuted,
      }

      const stream = await navigator.mediaDevices.getUserMedia(constraints)
      streamRef.current = stream

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
      }

      setIsConnected(true)
    } catch (error) {
      console.error("Error accessing camera:", error)
      let errorMessage = "Unable to access camera. "

      if (error.name === "NotAllowedError") {
        errorMessage += "Please allow camera access when prompted."
      } else if (error.name === "NotFoundError") {
        errorMessage += "No camera found on this device."
      } else if (error.name === "NotReadableError") {
        errorMessage += "Camera is already in use by another application."
      } else {
        errorMessage += "Please check your camera permissions and try again."
      }

      setStreamError(errorMessage)
      setIsConnected(false)
    }
  }

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null
    }
    setIsConnected(false)
    setIsStreaming(false)
    stopRecording()
  }

  const toggleCamera = () => {
    if (isConnected) {
      stopCamera()
    } else {
      startCamera()
    }
  }

  const toggleMute = async () => {
    if (streamRef.current) {
      const audioTracks = streamRef.current.getAudioTracks()
      audioTracks.forEach((track) => {
        track.enabled = isMuted
      })
      setIsMuted(!isMuted)
    }
  }

  const flipCamera = async () => {
    const newFacingMode = facingMode === "user" ? "environment" : "user"
    setFacingMode(newFacingMode)
    if (isConnected) {
      await startCamera()
    }
  }

  const startRecording = () => {
    if (!streamRef.current) return

    try {
      recordedChunksRef.current = []
      const mediaRecorder = new MediaRecorder(streamRef.current, {
        mimeType: "video/webm;codecs=vp9",
      })

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordedChunksRef.current.push(event.data)
        }
      }

      mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: "video/webm" })
        downloadRecording(blob)
      }

      mediaRecorderRef.current = mediaRecorder
      mediaRecorder.start()
      setIsRecording(true)
    } catch (error) {
      console.error("Error starting recording:", error)
      setStreamError("Unable to start recording. Your browser may not support this feature.")
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
    }
  }

  const downloadRecording = (blob: Blob) => {
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${match.day}-match-${new Date().toISOString().split("T")[0]}.webm`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const startStreaming = () => {
    if (!isConnected) {
      setStreamError("Please start camera first")
      return
    }
    setIsStreaming(true)
    startRecording()
  }

  const stopStreaming = () => {
    setIsStreaming(false)
    stopRecording()

    // End the match when stopping the stream
    if (isAdmin && onEndMatch) {
      const finalScore = `${homeScore}-${awayScore}`
      onEndMatch(finalScore)
    }
  }

  const handleScoreIncrement = (team: "home" | "away") => {
    setPendingGoalTeam(team)
    setShowGoalDialog(true)
  }

  const handleScoreDecrement = (team: "home" | "away") => {
    if (team === "home") {
      const newScore = Math.max(0, homeScore - 1)
      setHomeScore(newScore)
      onUpdateScore(newScore, awayScore)
    } else {
      const newScore = Math.max(0, awayScore - 1)
      setAwayScore(newScore)
      onUpdateScore(homeScore, newScore)
    }
  }

  const confirmGoal = () => {
    if (!pendingGoalTeam) return

    let newHomeScore = homeScore
    let newAwayScore = awayScore

    if (pendingGoalTeam === "home") {
      newHomeScore = homeScore + 1
      setHomeScore(newHomeScore)
    } else {
      newAwayScore = awayScore + 1
      setAwayScore(newAwayScore)
    }

    // Update the live score without ending the match
    onUpdateScore(newHomeScore, newAwayScore)

    // Reset dialog state
    setShowGoalDialog(false)
    setGoalScorerId("")
    setAssistPlayerId("")
    setPendingGoalTeam(null)
  }

  const cancelGoal = () => {
    setShowGoalDialog(false)
    setGoalScorerId("")
    setAssistPlayerId("")
    setPendingGoalTeam(null)
  }

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (message.trim()) {
      const newMessage = {
        id: Date.now(),
        player: currentUser,
        message: message.trim(),
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, newMessage])
      onSendMessage?.(message.trim())
      setMessage("")
    }
  }

  const homeTeam = match.home_team || { name: "Home Team", color: "#FF0000", logo_url: "/placeholder.svg" }
  const awayTeam = match.away_team || { name: "Away Team", color: "#0000FF", logo_url: "/placeholder.svg" }

  const formatTime = (time: string) => {
    if (!time) return ""
    const [hours, minutes] = time.split(":")
    const hour = Number.parseInt(hours)
    const ampm = hour >= 12 ? "PM" : "AM"
    const displayHour = hour % 12 || 12
    return `${displayHour}:${minutes} ${ampm}`
  }

  if (!isAdmin) {
    // Viewer mode - show live stream
    return (
      <div className="min-h-screen bg-black relative">
        {/* Header */}
        <header className="bg-black/80 backdrop-blur-sm text-white p-4 sticky top-0 z-50">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="icon" onClick={onBack} className="text-white hover:bg-white/20">
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="font-bold">{match.day} Match - LIVE</h1>
                <p className="text-sm text-gray-300">{match.location}</p>
                <p className="text-xs text-gray-400">At {formatTime(match.time)}</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              {isStreaming && (
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                  <span className="text-sm">LIVE</span>
                </div>
              )}
              <div className="flex items-center space-x-1">
                <Eye className="w-4 h-4" />
                <span className="text-sm">{viewers.length}</span>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setShowChat(!showChat)} className="text-white">
                <MessageCircle className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" onClick={toggleFullscreen} className="text-white">
                <Maximize className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </header>

        {/* Live Scoreboard - Top Left */}
        <div className="absolute top-20 left-4 z-40">
          <Card className="bg-black/80 backdrop-blur-sm border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-3">
                  <Avatar className="w-10 h-10 ring-2 ring-white">
                    <AvatarImage src={homeTeam.logo_url || "/placeholder.svg"} />
                    <AvatarFallback style={{ backgroundColor: homeTeam.color, color: "white" }}>
                      {homeTeam.name[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-white text-center">
                    <div className="text-sm font-medium">{homeTeam.name}</div>
                    <div className="text-2xl font-bold">{homeScore}</div>
                  </div>
                </div>

                <div className="text-white text-xl font-bold">-</div>

                <div className="flex items-center space-x-3">
                  <div className="text-white text-center">
                    <div className="text-sm font-medium">{awayTeam.name}</div>
                    <div className="text-2xl font-bold">{awayScore}</div>
                  </div>
                  <Avatar className="w-10 h-10 ring-2 ring-white">
                    <AvatarImage src={awayTeam.logo_url || "/placeholder.svg"} />
                    <AvatarFallback style={{ backgroundColor: awayTeam.color, color: "white" }}>
                      {awayTeam.name[0]}
                    </AvatarFallback>
                  </Avatar>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Live Video Stream */}
        <div className="relative w-full h-screen">
          {isStreaming ? (
            <div className="w-full h-full">
              {/* This shows the actual live camera feed */}
              <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline muted={false} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent pointer-events-none" />
            </div>
          ) : (
            <div className="w-full h-full bg-gray-900 flex items-center justify-center">
              <div className="text-center text-white">
                <Camera className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                <h2 className="text-xl font-bold mb-2">Stream Offline</h2>
                <p className="text-gray-400">The live stream is not currently active</p>
              </div>
            </div>
          )}
        </div>

        {/* Chat Panel */}
        {showChat && (
          <div className="absolute bottom-0 right-4 w-80 h-96 bg-black/80 backdrop-blur-sm border border-white/20 rounded-t-lg z-40">
            <div className="p-3 border-b border-white/20">
              <h3 className="text-white font-semibold">Live Chat</h3>
            </div>
            <div className="flex-1 p-3 h-64 overflow-y-auto">
              <div className="space-y-2">
                {messages.map((msg) => (
                  <div key={msg.id} className="text-white text-sm">
                    <span className="font-semibold text-blue-300">
                      {msg.player.name} {msg.player.surname}:
                    </span>
                    <span className="ml-2">{msg.message}</span>
                  </div>
                ))}
              </div>
            </div>
            <form onSubmit={sendMessage} className="p-3 border-t border-white/20">
              <div className="flex space-x-2">
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 bg-white/10 border-white/20 text-white placeholder-gray-400"
                />
                <Button type="submit" size="icon" className="bg-blue-600 hover:bg-blue-700">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </form>
          </div>
        )}
      </div>
    )
  }

  // Admin streaming mode
  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="bg-black/80 backdrop-blur-sm text-white p-4 sticky top-0 z-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="icon" onClick={onBack} className="text-white hover:bg-white/20">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-bold">Stream {match.day} Match</h1>
              <p className="text-sm text-gray-300">{match.location}</p>
              <p className="text-xs text-gray-400">At {formatTime(match.time)}</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {isStreaming && (
              <>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                  <span className="text-sm">LIVE</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Eye className="w-4 h-4" />
                  <span className="text-sm">{viewers.length}</span>
                </div>
              </>
            )}
            {isRecording && (
              <div className="flex items-center space-x-2 bg-red-600/20 px-2 py-1 rounded">
                <VideoIcon className="w-4 h-4 text-red-400" />
                <span className="text-sm text-red-400">REC {formatDuration(recordingDuration)}</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Live Score Management - Top Left */}
      <div className="absolute top-20 left-4 z-40">
        <Card className="bg-black/80 backdrop-blur-sm border-white/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-white text-sm">Live Score Control</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between space-x-6">
              {/* Home Team */}
              <div className="text-center">
                <div className="flex items-center space-x-2 mb-2">
                  <Avatar className="w-8 h-8 ring-2 ring-white">
                    <AvatarImage src={homeTeam.logo_url || "/placeholder.svg"} />
                    <AvatarFallback style={{ backgroundColor: homeTeam.color, color: "white" }}>
                      {homeTeam.name[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-white text-xs font-medium">{homeTeam.name}</div>
                </div>
                <div className="flex items-center space-x-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-6 h-6 text-white hover:bg-white/20"
                    onClick={() => handleScoreDecrement("home")}
                  >
                    <Minus className="w-3 h-3" />
                  </Button>
                  <span className="text-white text-2xl font-bold w-12 text-center">{homeScore}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-6 h-6 text-white hover:bg-white/20"
                    onClick={() => handleScoreIncrement("home")}
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
              </div>

              <div className="text-white text-xl font-bold">-</div>

              {/* Away Team */}
              <div className="text-center">
                <div className="flex items-center space-x-2 mb-2">
                  <Avatar className="w-8 h-8 ring-2 ring-white">
                    <AvatarImage src={awayTeam.logo_url || "/placeholder.svg"} />
                    <AvatarFallback style={{ backgroundColor: awayTeam.color, color: "white" }}>
                      {awayTeam.name[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-white text-xs font-medium">{awayTeam.name}</div>
                </div>
                <div className="flex items-center space-x-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-6 h-6 text-white hover:bg-white/20"
                    onClick={() => handleScoreDecrement("away")}
                  >
                    <Minus className="w-3 h-3" />
                  </Button>
                  <span className="text-white text-2xl font-bold w-12 text-center">{awayScore}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-6 h-6 text-white hover:bg-white/20"
                    onClick={() => handleScoreIncrement("away")}
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Goal Dialog */}
      <Dialog open={showGoalDialog} onOpenChange={setShowGoalDialog}>
        <DialogContent className="bg-black/90 border-white/20 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Target className="w-5 h-5 text-green-500" />
              <span>Goal Scored!</span>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Who scored the goal?</label>
              <Select value={goalScorerId} onValueChange={setGoalScorerId}>
                <SelectTrigger className="bg-white/10 border-white/20">
                  <SelectValue placeholder="Select goal scorer" />
                </SelectTrigger>
                <SelectContent className="bg-black border-white/20">
                  {players
                    .filter((p) => p.role === "player")
                    .map((player) => (
                      <SelectItem key={player.id} value={player.id.toString()} className="text-white hover:bg-white/10">
                        {player.name} {player.surname}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Who assisted? (Optional)</label>
              <Select value={assistPlayerId} onValueChange={setAssistPlayerId}>
                <SelectTrigger className="bg-white/10 border-white/20">
                  <SelectValue placeholder="Select assist player or leave empty" />
                </SelectTrigger>
                <SelectContent className="bg-black border-white/20">
                  <SelectItem value="" className="text-white hover:bg-white/10">
                    No assist
                  </SelectItem>
                  {players
                    .filter((p) => p.role === "player" && p.id.toString() !== goalScorerId)
                    .map((player) => (
                      <SelectItem key={player.id} value={player.id.toString()} className="text-white hover:bg-white/10">
                        {player.name} {player.surname}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex space-x-2">
              <Button onClick={confirmGoal} className="flex-1 bg-green-600 hover:bg-green-700">
                <Target className="w-4 h-4 mr-2" />
                Confirm Goal
              </Button>
              <Button
                onClick={cancelGoal}
                variant="outline"
                className="flex-1 border-white/20 text-white hover:bg-white/10 bg-transparent"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Video Preview */}
      <div className="relative w-full h-screen">
        <video ref={videoRef} className="w-full h-full object-cover" muted={isMuted} playsInline />

        {!isConnected && (
          <div className="absolute inset-0 bg-gray-900 flex items-center justify-center">
            <div className="text-center text-white max-w-md px-4">
              <Camera className="w-16 h-16 mx-auto mb-4 text-gray-500" />
              <h2 className="text-xl font-bold mb-2">Camera Off</h2>
              <p className="text-gray-400 mb-4">Start camera to begin streaming</p>
              {streamError && (
                <div className="bg-red-900/50 border border-red-500 rounded-lg p-3 mb-4">
                  <p className="text-red-200 text-sm">{streamError}</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Enhanced Controls */}
      <div className="absolute bottom-0 left-0 right-0 bg-black/80 backdrop-blur-sm p-4">
        <div className="flex items-center justify-center space-x-4">
          <Button
            variant={isConnected ? "destructive" : "default"}
            onClick={toggleCamera}
            className="flex items-center space-x-2"
          >
            {isConnected ? <CameraOff className="w-4 h-4" /> : <Camera className="w-4 h-4" />}
            <span>{isConnected ? "Stop Camera" : "Start Camera"}</span>
          </Button>

          {isConnected && (
            <>
              <Button
                variant={isMuted ? "destructive" : "outline"}
                onClick={toggleMute}
                className="flex items-center space-x-2 bg-transparent"
              >
                {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                <span>{isMuted ? "Unmute" : "Mute"}</span>
              </Button>

              <Button variant="outline" onClick={flipCamera} className="flex items-center space-x-2 bg-transparent">
                <RotateCcw className="w-4 h-4" />
                <span>Flip Camera</span>
              </Button>
            </>
          )}

          <Button
            variant={isStreaming ? "destructive" : "default"}
            onClick={isStreaming ? stopStreaming : startStreaming}
            disabled={!isConnected}
            className="flex items-center space-x-2"
          >
            {isStreaming ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isStreaming ? "End Match & Stop Stream" : "Go Live & Record"}</span>
          </Button>
        </div>
      </div>
    </div>
  )
}
