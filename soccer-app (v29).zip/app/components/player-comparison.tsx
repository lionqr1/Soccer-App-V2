"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Search, Trophy, Target, Star, Calendar, TrendingUp, Users, Crown } from "lucide-react"

interface PlayerComparisonProps {
  currentUser: any
  players: any[]
  matches: any[]
  onBack: () => void
}

export function PlayerComparison({ currentUser, players, matches, onBack }: PlayerComparisonProps) {
  const [searchUsername, setSearchUsername] = useState("")
  const [comparisonPlayer, setComparisonPlayer] = useState<any>(null)
  const [searchResults, setSearchResults] = useState<any[]>([])

  const handleSearch = () => {
    if (!searchUsername.trim()) {
      setSearchResults([])
      return
    }

    const results = players.filter(
      (player) => player.username.toLowerCase().includes(searchUsername.toLowerCase()) && player.id !== currentUser.id,
    )
    setSearchResults(results)
  }

  const selectPlayerForComparison = (player: any) => {
    setComparisonPlayer(player)
    setSearchResults([])
    setSearchUsername("")
  }

  const calculateStats = (player: any) => {
    const playerMatches = matches.filter((match) => match.attendees?.some((attendee) => attendee.id === player.id))

    const playedMatches = playerMatches.filter((match) => {
      const attendee = match.attendees?.find((a) => a.id === player.id)
      return attendee && !attendee.injured && match.status === "completed"
    })

    const totalGoals = matches.reduce((total, match) => {
      const scorer = match.goalScorers?.find((s) => s.playerId === player.id)
      return total + (scorer?.goals || 0)
    }, 0)

    const totalAssists = matches.reduce((total, match) => {
      const assist = match.assists?.find((a) => a.playerId === player.id)
      return total + (assist?.assists || 0)
    }, 0)

    const mvpCount = matches.filter((match) => match.mvp?.id === player.id).length
    const attendanceRate = playerMatches.length > 0 ? Math.round((playerMatches.length / matches.length) * 100) : 0

    return {
      totalGoals,
      totalAssists,
      mvpCount,
      playedMatches: playedMatches.length,
      attendanceRate,
      totalMatches: playerMatches.length,
    }
  }

  const currentUserStats = calculateStats(currentUser)
  const comparisonStats = comparisonPlayer ? calculateStats(comparisonPlayer) : null

  const getWinner = (stat1: number, stat2: number) => {
    if (stat1 > stat2) return "current"
    if (stat2 > stat1) return "comparison"
    return "tie"
  }

  const StatComparison = ({
    icon,
    label,
    currentValue,
    comparisonValue,
    color,
  }: {
    icon: React.ReactNode
    label: string
    currentValue: number
    comparisonValue: number
    color: string
  }) => {
    const winner = getWinner(currentValue, comparisonValue)

    return (
      <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center space-x-3">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${color}`}>{icon}</div>
          <span className="font-medium text-gray-900">{label}</span>
        </div>

        <div className="flex items-center space-x-4">
          <div className={`text-center ${winner === "current" ? "text-green-600 font-bold" : "text-gray-600"}`}>
            <div className="text-xl font-bold">{currentValue}</div>
            <div className="text-xs">You</div>
            {winner === "current" && <Crown className="w-4 h-4 mx-auto text-yellow-500" />}
          </div>

          <div className="text-gray-400">vs</div>

          <div className={`text-center ${winner === "comparison" ? "text-green-600 font-bold" : "text-gray-600"}`}>
            <div className="text-xl font-bold">{comparisonValue}</div>
            <div className="text-xs">Them</div>
            {winner === "comparison" && <Crown className="w-4 h-4 mx-auto text-yellow-500" />}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="px-4 py-3">
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-semibold text-gray-900">Player Comparison</h1>
          </div>
        </div>
      </header>

      <main className="p-4 pb-20">
        {/* Search Section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Compare with Another Player</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="search">Enter username to compare</Label>
              <div className="flex space-x-2">
                <Input
                  id="search"
                  value={searchUsername}
                  onChange={(e) => setSearchUsername(e.target.value)}
                  placeholder="Enter username..."
                  onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                />
                <Button onClick={handleSearch}>
                  <Search className="w-4 h-4 mr-2" />
                  Search
                </Button>
              </div>
            </div>

            {/* Search Results */}
            {searchResults.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-medium text-sm text-gray-600">Search Results:</h4>
                {searchResults.map((player) => (
                  <div
                    key={player.id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
                    onClick={() => selectPlayerForComparison(player)}
                  >
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-10 h-10 ring-2 ring-white">
                        <AvatarImage src={player.profile_image || "/placeholder.svg"} />
                        <AvatarFallback className="bg-white">
                          {player.name[0]}
                          {player.surname[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">
                          {player.name} {player.surname}
                        </div>
                        <div className="text-sm text-gray-600">@{player.username}</div>
                      </div>
                    </div>
                    <Button size="sm">Compare</Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Comparison Results */}
        {comparisonPlayer && comparisonStats && (
          <div className="space-y-6">
            {/* Player Headers */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="text-center">
                    <Avatar className="w-20 h-20 mx-auto mb-3 ring-4 ring-blue-200">
                      <AvatarImage src={currentUser.profile_image || "/placeholder.svg"} />
                      <AvatarFallback className="bg-white text-xl font-bold">
                        {currentUser.name[0]}
                        {currentUser.surname[0]}
                      </AvatarFallback>
                    </Avatar>
                    <h3 className="font-bold text-lg">
                      {currentUser.name} {currentUser.surname}
                    </h3>
                    <p className="text-sm text-gray-600">@{currentUser.username}</p>
                    <Badge variant="default" className="mt-2">
                      You
                    </Badge>
                  </div>

                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-400">VS</div>
                  </div>

                  <div className="text-center">
                    <Avatar className="w-20 h-20 mx-auto mb-3 ring-4 ring-green-200">
                      <AvatarImage src={comparisonPlayer.profile_image || "/placeholder.svg"} />
                      <AvatarFallback className="bg-white text-xl font-bold">
                        {comparisonPlayer.name[0]}
                        {comparisonPlayer.surname[0]}
                      </AvatarFallback>
                    </Avatar>
                    <h3 className="font-bold text-lg">
                      {comparisonPlayer.name} {comparisonPlayer.surname}
                    </h3>
                    <p className="text-sm text-gray-600">@{comparisonPlayer.username}</p>
                    <Badge variant="secondary" className="mt-2">
                      Opponent
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Stats Comparison */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Trophy className="w-5 h-5 text-yellow-600" />
                  <span>Performance Comparison</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <StatComparison
                  icon={<Target className="w-5 h-5 text-white" />}
                  label="Total Goals"
                  currentValue={currentUserStats.totalGoals}
                  comparisonValue={comparisonStats.totalGoals}
                  color="bg-green-600"
                />

                <StatComparison
                  icon={<Users className="w-5 h-5 text-white" />}
                  label="Total Assists"
                  currentValue={currentUserStats.totalAssists}
                  comparisonValue={comparisonStats.totalAssists}
                  color="bg-blue-600"
                />

                <StatComparison
                  icon={<Star className="w-5 h-5 text-white" />}
                  label="MVP Awards"
                  currentValue={currentUserStats.mvpCount}
                  comparisonValue={comparisonStats.mvpCount}
                  color="bg-yellow-600"
                />

                <StatComparison
                  icon={<Calendar className="w-5 h-5 text-white" />}
                  label="Matches Played"
                  currentValue={currentUserStats.playedMatches}
                  comparisonValue={comparisonStats.playedMatches}
                  color="bg-purple-600"
                />

                <StatComparison
                  icon={<TrendingUp className="w-5 h-5 text-white" />}
                  label="Attendance Rate (%)"
                  currentValue={currentUserStats.attendanceRate}
                  comparisonValue={comparisonStats.attendanceRate}
                  color="bg-indigo-600"
                />
              </CardContent>
            </Card>

            {/* Overall Winner */}
            <Card>
              <CardContent className="p-6 text-center">
                {(() => {
                  const currentWins = [
                    getWinner(currentUserStats.totalGoals, comparisonStats.totalGoals),
                    getWinner(currentUserStats.totalAssists, comparisonStats.totalAssists),
                    getWinner(currentUserStats.mvpCount, comparisonStats.mvpCount),
                    getWinner(currentUserStats.playedMatches, comparisonStats.playedMatches),
                    getWinner(currentUserStats.attendanceRate, comparisonStats.attendanceRate),
                  ].filter((result) => result === "current").length

                  const comparisonWins = [
                    getWinner(currentUserStats.totalGoals, comparisonStats.totalGoals),
                    getWinner(currentUserStats.totalAssists, comparisonStats.totalAssists),
                    getWinner(currentUserStats.mvpCount, comparisonStats.mvpCount),
                    getWinner(currentUserStats.playedMatches, comparisonStats.playedMatches),
                    getWinner(currentUserStats.attendanceRate, comparisonStats.attendanceRate),
                  ].filter((result) => result === "comparison").length

                  if (currentWins > comparisonWins) {
                    return (
                      <div className="text-green-600">
                        <Crown className="w-12 h-12 mx-auto mb-3 text-yellow-500" />
                        <h3 className="text-xl font-bold">You Win!</h3>
                        <p className="text-gray-600">
                          You outperformed {comparisonPlayer.name} in {currentWins} out of 5 categories
                        </p>
                      </div>
                    )
                  } else if (comparisonWins > currentWins) {
                    return (
                      <div className="text-red-600">
                        <Trophy className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                        <h3 className="text-xl font-bold">{comparisonPlayer.name} Wins!</h3>
                        <p className="text-gray-600">
                          {comparisonPlayer.name} outperformed you in {comparisonWins} out of 5 categories
                        </p>
                      </div>
                    )
                  } else {
                    return (
                      <div className="text-gray-600">
                        <Trophy className="w-12 h-12 mx-auto mb-3 text-yellow-500" />
                        <h3 className="text-xl font-bold">It's a Tie!</h3>
                        <p className="text-gray-600">You and {comparisonPlayer.name} are evenly matched</p>
                      </div>
                    )
                  }
                })()}
              </CardContent>
            </Card>

            <Button variant="outline" onClick={() => setComparisonPlayer(null)} className="w-full">
              Compare with Another Player
            </Button>
          </div>
        )}
      </main>
    </div>
  )
}
